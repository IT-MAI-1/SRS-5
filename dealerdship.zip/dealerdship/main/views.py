from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import render, get_object_or_404
from .models import Car, Order
from django.http import JsonResponse
import json, re

def catalog_view(request):
    cars = Car.objects.all()
    return render(request, 'main/catalog.html', {'cars': cars})

def car_detail_view(request, car_id):
    car = get_object_or_404(Car, id=car_id)
    return render(request, 'main/car_detail.html', {'car': car})

def format_phone(phone):
    digits = re.sub(r'\D', '', phone)
    if len(digits) == 11 and digits[0] in ['7', '8']:
        return f"+7 ({digits[1:4]}) {digits[4:7]}-{digits[7:9]}-{digits[9:11]}"
    return phone

def create_order_api(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        car_id = data.get('car_id')
        name = data.get('name')
        raw_phone = data.get('phone')
        clean_phone = format_phone(raw_phone)
        
        Order.objects.create(
            car_id=car_id,
            client_name=name,
            client_phone=clean_phone
        )
        return JsonResponse({'status': 'success', 'message': 'Заявка успешно создана!'})
    return JsonResponse({'status': 'error', 'message': 'Неверный метод'}, status=400)


@staff_member_required
def dashboard_view(request):
    orders = Order.objects.all().order_by('-created_at')
    return render(request, 'main/dashboard.html', {'orders': orders})

def update_order_api(request):
    """Изменение статуса заявки без перезагрузки страницы"""
    if request.method == 'POST':
        data = json.loads(request.body)
        order_id = data.get('order_id')
        new_status = data.get('status')
        
        order = get_object_or_404(Order, id=order_id)
        order.status = new_status
        order.save()
        return JsonResponse({'status': 'success', 'message': 'Статус заявки обновлен!'})
    return JsonResponse({'status': 'error', 'message': 'Неверный метод'}, status=400)

def delete_order_api(request):
    """Удаление заявки без перезагрузки страницы"""
    if request.method == 'POST':
        data = json.loads(request.body)
        order_id = data.get('order_id')
        
        order = get_object_or_404(Order, id=order_id)
        order.delete()
        return JsonResponse({'status': 'success', 'message': 'Заявка удалена!'})
    return JsonResponse({'status': 'error', 'message': 'Неверный метод'}, status=400)


def favorites_view(request):
    ids_str = request.GET.get('ids', '')
    if ids_str:
        ids = [int(id) for id in ids_str.split(',') if id.isdigit()]
        cars = Car.objects.filter(id__in=ids)
    else:
        cars = []
    return render(request, 'main/favorites.html', {'cars': cars})