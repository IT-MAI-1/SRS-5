from django.urls import path
from . import views

urlpatterns = [
    path('', views.catalog_view, name='catalog'),
    path('car/<int:car_id>/', views.car_detail_view, name='car_detail'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('favorites/', views.favorites_view, name='favorites'),
    
    path('api/create-order/', views.create_order_api, name='create_order_api'),
    path('api/update-order/', views.update_order_api, name='update_order_api'),
    path('api/delete-order/', views.delete_order_api, name='delete_order_api'),   
]